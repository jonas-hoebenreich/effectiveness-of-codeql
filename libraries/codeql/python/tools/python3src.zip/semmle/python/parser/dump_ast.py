
from __future__ import print_function
from ast import literal_eval
import sys
import semmle.python.parser.tokenizer
import semmle.python.parser
from semmle.python import ast
from semmle import logging
from semmle.python.modules import PythonSourceModule
import subprocess
DEBUG = False

def debug_print(*args, **kwargs):
    if DEBUG:
        print(*args, **kwargs)

class Node(object):

    def __init__(self, id):
        self.id = id

    def __repr__(self):
        return 'Node({})'.format(self.id)

class Comment(object):

    def __init__(self, text):
        self.text = text

    def __repr__(self):
        return 'Comment({})'.format(self.text)
tsg_to_ast = {name: cls for (name, cls) in semmle.python.ast.__dict__.items() if (isinstance(cls, type) and (ast.AstBase in cls.__mro__))}
tsg_to_ast['Comment'] = Comment
ast_fields = {ast.Module: ('body',), Comment: ('text',), ast.Continue: (), ast.Break: (), ast.Pass: (), ast.Ellipsis: ()}
ignored_fields = semmle.python.ast.AstBase.__slots__
for (name, cls) in semmle.python.ast.__dict__.items():
    if name.startswith('_'):
        continue
    if (not hasattr(cls, '__slots__')):
        continue
    slots = tuple((field for field in cls.__slots__ if (field not in ignored_fields)))
    if (not slots):
        continue
    ast_fields[cls] = slots
locationless = {'+': ast.Add, '+=': ast.Add, '-': ast.Sub, '-=': ast.Sub, '*': ast.Mult, '*=': ast.Mult, '/': ast.Div, '/=': ast.Div, '//': ast.FloorDiv, '//=': ast.FloorDiv, '%': ast.Mod, '%=': ast.Mod, '**': ast.Pow, '**=': ast.Pow, '<<': ast.LShift, '<<=': ast.LShift, '>>': ast.RShift, '>>=': ast.RShift, '&': ast.BitAnd, '&=': ast.BitAnd, '|': ast.BitOr, '|=': ast.BitOr, '^': ast.BitXor, '^=': ast.BitXor, '@': ast.MatMult, '@=': ast.MatMult, '~': ast.Invert, '<': ast.Lt, '<=': ast.LtE, '>': ast.Gt, '>=': ast.GtE, '==': ast.Eq, '!=': ast.NotEq, 'is': ast.Is, 'is not': ast.IsNot, 'in': ast.In, 'not in': ast.NotIn, 'load': ast.Load, 'store': ast.Store, 'del': ast.Del}

def read_tsg_python_output(path):
    node_attr = {}
    edge_attr = {}
    is_python_2 = (sys.version_info < (3,))
    command_args = ['cargo', 'run', '--quiet', '--manifest-path=tsg-python/Cargo.toml', 'tsg-python/python.tsg', path]
    p = subprocess.Popen(command_args, stdout=subprocess.PIPE)
    for line in p.stdout:
        line = line.decode(sys.getfilesystemencoding())
        line = line.rstrip()
        if line.startswith('node'):
            current_node = int(line.split(' ')[1])
            d = {}
            node_attr[current_node] = d
            in_node = True
        elif line.startswith('edge'):
            (current_start, current_end) = tuple(map(int, line[4:].split('->')))
            d = edge_attr.setdefault(current_start, {})
            in_node = False
        else:
            (key, value) = line[2:].split(': ', 1)
            if value.startswith('[graph node'):
                value = Node(int(value.split(' ')[2][:(- 1)]))
            elif (value == '#true'):
                value = True
            elif (value == '#false'):
                value = False
            elif (value == '#null'):
                value = None
            else:
                value = literal_eval(value)
                if (is_python_2 and isinstance(value, str)):
                    value = value.decode(sys.getfilesystemencoding())
            if in_node:
                d[key] = value
            else:
                d.setdefault(key, []).append((value, current_end))
    p.stdout.close()
    p.terminate()
    p.wait()
    return (node_attr, edge_attr)

def resolve_node_id(id, node_attr):
    while ('_skip_to' in node_attr[id]):
        id = node_attr[id]['_skip_to'].id
    return id

def get_context(id, node_attr):
    while ('ctx' not in node_attr[id]):
        if ('_inherited_ctx' not in node_attr[id]):
            sys.stderr.write('Error! No context for node {} with attributes {}\n'.format(id, node_attr[id]))
            return None
        id = node_attr[id]['_inherited_ctx'].id
    return locationless[node_attr[id]['ctx']]()

def get_location_info(attrs):
    start_line = '???'
    start_column = '???'
    end_line = '???'
    end_column = '???'
    if ('_location' in attrs):
        (start_line, start_column, end_line, end_column) = attrs['_location']
    if ('_location_start' in attrs):
        (start_line, start_column) = attrs['_location_start']
    if ('_location_end' in attrs):
        (end_line, end_column) = attrs['_location_end']
    if ('_start_line' in attrs):
        start_line = attrs['_start_line']
    if ('_start_column' in attrs):
        start_column = attrs['_start_column']
    if ('_end_line' in attrs):
        end_line = attrs['_end_line']
    if ('_end_column' in attrs):
        end_column = attrs['_end_column']
    if (start_line != '???'):
        start_line += 1
    if (end_line != '???'):
        end_line += 1
    return (start_line, start_column, end_line, end_column)
list_fields = {ast.arguments: ('annotations', 'defaults', 'kw_defaults', 'kw_annotations'), ast.Assign: ('targets',), ast.BoolOp: ('values',), ast.Bytes: ('implicitly_concatenated_parts',), ast.Call: ('positional_args', 'named_args'), ast.Class: ('body',), ast.ClassExpr: ('bases', 'keywords'), ast.Compare: ('ops', 'comparators'), ast.comprehension: ('ifs',), ast.Delete: ('targets',), ast.Dict: ('items',), ast.ExceptStmt: ('body',), ast.For: ('body',), ast.Function: ('args', 'kwonlyargs', 'body'), ast.Global: ('names',), ast.If: ('body',), ast.Import: ('names',), ast.List: ('elts',), ast.ListComp: ('generators',), ast.Module: ('body',), ast.Nonlocal: ('names',), ast.Print: ('values',), ast.Set: ('elts',), ast.Str: ('implicitly_concatenated_parts',), ast.Try: ('body', 'handlers', 'orelse', 'finalbody'), ast.Tuple: ('elts',), ast.While: ('body',)}

def create_placeholder_args(cls):
    if (cls == ast.Raise):
        return {}
    fields = ast_fields[cls]
    args = {field: None for field in fields if (field != 'is_async')}
    for field in list_fields.get(cls, ()):
        args[field] = []
    return args

def new_parser(path):
    (node_attr, edge_attr) = read_tsg_python_output(path)
    debug_print('node_attr:', node_attr)
    debug_print('edge_attr:', edge_attr)
    nodes = {}
    for (id, attrs) in node_attr.items():
        if ('_is_literal' in attrs):
            nodes[id] = attrs['_is_literal']
            continue
        if ('_kind' not in attrs):
            sys.stderr.write('Error: Graph node {} with attributes {} has no `_kind`!\n'.format(id, attrs))
            continue
        if ('_skip_to' in attrs):
            continue
        cls = tsg_to_ast[attrs['_kind']]
        args = ast_fields[cls]
        nodes[id] = cls(**create_placeholder_args(cls))
    for (id, node) in nodes.items():
        attrs = node_attr[id]
        if ('_is_literal' in attrs):
            continue
        expected_fields = ast_fields[type(node)]
        (node.lineno, node.col_offset, end_line, end_column) = get_location_info(attrs)
        node._end = (end_line, end_column)
        if ('ctx' in expected_fields):
            node.ctx = get_context(id, node_attr)
        for (field, val) in attrs.items():
            if field.startswith('_'):
                continue
            if (field == 'ctx'):
                continue
            if ((field != 'parenthesised') and (field not in expected_fields)):
                sys.stderr.write('Warning: Unknown field {} found among {} in node {}\n'.format(field, attrs, id))
            if isinstance(val, Node):
                val = resolve_node_id(val.id, node_attr)
                setattr(node, field, nodes[val])
            elif (isinstance(node, ast.Num) and (field == 'n')):
                node.n = int(val)
            elif (isinstance(node, ast.Name) and (field == 'variable')):
                node.variable = ast.Variable(val)
            elif (val in locationless.keys()):
                setattr(node, field, locationless[val]())
            else:
                setattr(node, field, val)
    for (start, field_map) in edge_attr.items():
        start = resolve_node_id(start, node_attr)
        parent = nodes[start]
        for (field_name, value_end) in field_map.items():
            children = [nodes[resolve_node_id(end, node_attr)] for (_index, end) in sorted(value_end)]
            children = [child for child in children if (not isinstance(child, Comment))]
            setattr(parent, field_name, children)
    debug_print('nodes:', nodes)
    if (not nodes):
        module = ast.Module([])
        module.lineno = 1
        module.col_offset = 0
        module._end = (1, 0)
        return module
    module = nodes[0]
    if module.body:
        module.lineno = module.body[0].lineno
    else:
        module.lineno = module._end[0]
    return module

def get_fields(cls):
    if (cls not in ast_fields):
        return ()
    s = cls.__bases__[0]
    return (ast_fields[cls] + get_fields(s))

def missing_fields(known, node):
    return [field for field in dir(node) if ((field not in known) and (not field.startswith('_')) and (not (field in ('lineno', 'col_offset'))) and (not (isinstance(node, ast.Name) and (field == 'id'))))]

class AstDumper(object):

    def __init__(self, output=sys.stdout):
        self.output = output

    def visit(self, node, level=0):
        output = self.output
        cls = node.__class__
        name = cls.__name__
        indent = ('  ' * level)
        if (node is None):
            name = 'None'
        if (cls == str):
            output.write('{}{}\n'.format(indent, repr(node)))
            return
        if (not hasattr(node, 'lineno')):
            output.write('{}{}\n'.format(indent, name))
            return
        position = (node.lineno, node.col_offset, node._end[0], node._end[1])
        output.write('{}{}: [{}, {}] - [{}, {}]\n'.format(indent, name, *position))
        fields = get_fields(cls)
        unknown = missing_fields(fields, node)
        if unknown:
            output.write('{}UNKNOWN FIELDS: {}\n'.format(indent, unknown))
        for field in fields:
            value = getattr(node, field, None)
            if ((field == 'parenthesised') and (value is None)):
                continue
            if ((field == 'is_async') and (value is False)):
                continue
            output.write('{}  {}:'.format(indent, field))
            if isinstance(value, list):
                output.write(' [')
                if (len(value) == 0):
                    output.write(']\n')
                    return
                output.write('\n')
                for n in value:
                    self.visit(n, (level + 2))
                output.write('{}  ]\n'.format(indent))
            elif isinstance(value, (ast.expr_context, ast.boolop, ast.cmpop, ast.operator, ast.unaryop)):
                output.write(' {}\n'.format(value.__class__.__name__))
            elif isinstance(value, ast.AstBase):
                output.write('\n')
                self.visit(value, (level + 2))
            else:
                output.write(' {}\n'.format(repr(value)))

class StderrLogger(logging.Logger):

    def log(self, level, fmt, *args):
        sys.stderr.write(((fmt % args) + '\n'))

def old_parser(inputfile):
    logger = StderrLogger()
    mod = PythonSourceModule(None, inputfile, logger)
    logger.close()
    return mod.py_ast

def args_parser():
    from optparse import OptionParser
    usage = 'usage: %prog [options] python-file'
    parser = OptionParser(usage=usage)
    parser.add_option('-o', '--old', help='Dump old AST.', action='store_true')
    parser.add_option('-n', '--new', help='Dump new AST.', action='store_true')
    parser.add_option('-d', '--debug', help='Print debug information.', action='store_true')
    return parser

def main():
    parser = args_parser()
    (options, args) = parser.parse_args(sys.argv[1:])
    if options.debug:
        global DEBUG
        DEBUG = True
    if (len(args) != 1):
        sys.stderr.write('Error: wrong number of arguments.\n')
        parser.print_help()
        sys.exit(1)
    inputfile = args[0]
    if (options.old and options.new):
        sys.stderr.write('Error: options --old and --new are mutually exclusive.\n')
        sys.exit(1)
    if (not (options.old or options.new)):
        sys.stderr.write('Error: Must specify either --old or --new.\n')
        sys.exit(1)
    if options.old:
        ast = old_parser(inputfile)
    else:
        ast = new_parser(inputfile)
    AstDumper().visit(ast)
if (__name__ == '__main__'):
    main()
